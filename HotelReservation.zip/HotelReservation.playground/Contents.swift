import Foundation

// Struct Clientes
struct Client: Equatable {
    let name: String
    let age: Int
    let height: Double
}

let piccolo = Client(name: "Piccolo", age: 27, height: 226)
let vegeta = Client(name: "Vegeta", age: 48, height: 164)
let krilin = Client(name: "Krilin", age: 20, height: 145.5)
let freezer = Client(name: "Freezer", age: 52, height: 184.2)
let androide19 = Client(name: "Androide19", age: 99, height: 194)
let bulma = Client(name: "Bulma", age: 28, height: 160)
let goku = Client(name: "Goku", age: 34, height: 178)
let master = Client(name: "Master", age: 120, height: 157)
let boo = Client(name: "Boo", age: 30, height: 190)
let trunks = Client(name: "Trunks", age: 26, height: 180)

// Struct Reserva
struct Reservation {
    var id = UUID()
    var hotelName: String = ""
    var clientList: [Client]
    var duration: Int
    var price: Double = 20
    var breakfast: Bool
}

enum ReservationError: LocalizedError {
    case reservationIdExist
    case reservationClientExist
    case reservationDontExist
    
    var errorDescription: String? {
        switch self{
        case .reservationIdExist:
            return "The ID selected already exists."
        case .reservationClientExist:
            return "Some Client is already included in other reservation."
        case.reservationDontExist:
            return "ID for reservation not found."
        }
    }
}



class HotelReservationManager {
    
    private var reservationList: [Reservation] = []
    
    // Función cálculo de precio
    func priceCalculate (reservation: Reservation) -> Double{
        
        var price = Double(reservation.clientList.count) * reservation.price * Double(reservation.duration)
        
        if reservation.breakfast {
            return price * 1.25
        }
        
        return price
    }
    
    //Validar Cliente
    func validateClient(clients: [Client]) throws{
        try reservationList.forEach { reservation in
            try clients.forEach { client in
                if reservation.clientList.contains(client){
                    throw ReservationError.reservationClientExist
                }
            }
        }
        
    }
    
    // Validar Id
    func validateId(id: UUID) throws{
        if let _ = reservationList.first(where: {$0.id == id}){
            throw ReservationError.reservationIdExist
        }
    }
    
    func validateReservation(data: Reservation) throws{
        try validateId(id: data.id)
        try validateClient(clients: data.clientList)

    }
    
    // Función crear reserva
    func reservationCreate(reservationData: Reservation) -> Reservation? {
        
        var reservation = reservationData
        reservation.hotelName = "Hotel Luchadores"
        reservation.price = priceCalculate(reservation: reservation)
        
        do{
            try validateReservation(data: reservation)
            reservationList.append(reservation)
            print("Reservation with id: \(reservation.id) has been registered")
            print("The price of your reservation increases to: \(reservation.price) €")
            return reservation
            
        } catch{
            print(error.localizedDescription)
            return nil
        }
    }
    
    // Funcion eliminar una reserva e Id inexistente
    func deleteReservation(id: UUID) throws{
        if let index = reservationList.firstIndex(where: {$0.id == id}){
            reservationList.remove(at: index)
            print("Reservation with id: \(id), has been removed")
        } else {
            throw ReservationError.reservationDontExist
        }
    }
    // Mostrar reservas guardadas
    func viewReservations() -> [Reservation]{
        reservationList.forEach { reservation in
            print("")
            print("Id : \(reservation.id)")
            print("Hotel: \(reservation.hotelName)")
            print("Clients: \(reservation.clientList.map({$0.name}).joined(separator: ", "))")
            print("Days: \(reservation.duration)")
            print("Breakfast: \(reservation.breakfast)")
            print("Price: \(reservation.price)")
            print("")
        }
        return reservationList
    }
    
    // TEST
    
    func testAddReservation(){
        
        var reservationPiccolo = Reservation(clientList: [piccolo, vegeta], duration: 3, breakfast: true)
        reservationCreate(reservationData: reservationPiccolo)
        var reservation = reservationList.first
        
        assert(reservation != nil)
        assert(reservation!.id.uuidString != "")
        assert(reservation!.clientList.count == 2)
        assert(reservation!.price == 150.0)
        

        var reservationKrilin = Reservation(clientList: [krilin, bulma, freezer], duration: 5, breakfast: false)
        reservationCreate(reservationData: reservationKrilin)

        var reservationGoku = Reservation(clientList: [goku], duration: 2, breakfast: true)
        reservationCreate(reservationData: reservationGoku)
        
        assert(reservationList.count == 3)
        
        var copiaReservationGoku = reservationGoku
        reservationGoku.clientList = [master]
        reservationCreate(reservationData: reservationGoku)
        
        assert(reservationList.count == 3)

        var reservationAndroide19 = Reservation(clientList: [androide19], duration: 7, breakfast: true)
        reservationCreate(reservationData: reservationAndroide19)

        var reservationAndroide19two = Reservation(clientList: [androide19, goku], duration: 7, breakfast: true)
        reservationCreate(reservationData: reservationAndroide19two)
        
        assert(reservationList.count == 4)

    }
    func testCancelReservation(){
        guard !reservationList.isEmpty, let reservation = reservationList.first else{
            return
        }
        do{
            let counter = reservationList.count
            try deleteReservation(id: reservation.id)
            
            assert(reservationList.count == counter - 1)
            
            let id = UUID()
            try deleteReservation(id: id)
            
            assert(reservationList.count == counter - 1)
        
        } catch {
            print(error.localizedDescription)
        }
    }
    func testReservationPrice() {
        
        var reservationBoo = Reservation(clientList: [boo], duration: 3, breakfast: false)
        reservationCreate(reservationData: reservationBoo)
        
        var reservationTrunks = Reservation(clientList: [trunks], duration: 3, breakfast: false)
        let reservationInfo = reservationCreate(reservationData: reservationTrunks)
        
        assert(reservationInfo?.price == 60.0)
        assert(reservationBoo.price == reservationTrunks.price)
    
    }
}


   
var hotelReservationManager = HotelReservationManager()

hotelReservationManager.testAddReservation()
hotelReservationManager.testCancelReservation()
hotelReservationManager.testReservationPrice()

hotelReservationManager.viewReservations()





